<script lang="ts">
  import { onMount } from 'svelte';
  import AssetList from './lib/AssetList.svelte';
  import BookingForm from './lib/BookingForm.svelte';
  import { mockAssets } from './lib/data';
  import type { Asset } from './lib/types';
  
  let assets: Asset[] = [];
  let selectedAsset: Asset | null = null;
  
  // Simulate loading assets from an API
  onMount(() => {
    // Simulate API delay
    setTimeout(() => {
      assets = mockAssets;
    }, 500);
  });
  
  function handleAssetSelect(event: CustomEvent<Asset>) {
    selectedAsset = event.detail;
  }
  
  function handleBookingSubmit() {
    // Reset selected asset after successful booking
    alert('Booking successful!');
    selectedAsset = null;
  }
</script>

<main>
  <header>
    <h1>Asset Booking System</h1>
  </header>
  
  <div class="container">
    <div class="assets-container">
      <h2>Available Assets</h2>
      <AssetList {assets} on:selectAsset={handleAssetSelect} />
    </div>
    
    <div class="booking-container">
      <h2>Book an Asset</h2>
      {#if selectedAsset}
        <BookingForm 
          asset={selectedAsset} 
          on:bookingSubmit={handleBookingSubmit}
        />
      {:else}
        <p class="select-prompt">Please select an asset from the list to book</p>
      {/if}
    </div>
  </div>
</main>

<style>
  main {
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
  }
  
  header {
    background-color: #2c3e50;
    color: white;
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 5px;
  }
  
  h1 {
    margin: 0;
    font-size: 1.8rem;
  }
  
  h2 {
    color: #2c3e50;
    border-bottom: 2px solid #eee;
    padding-bottom: 10px;
    margin-top: 0;
  }
  
  .container {
    display: flex;
    gap: 20px;
  }
  
  .assets-container,
  .booking-container {
    background: white;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    flex: 1;
  }
  
  .select-prompt {
    color: #666;
    font-style: italic;
    text-align: center;
    margin-top: 30px;
  }
  
  @media (max-width: 768px) {
    .container {
      flex-direction: column;
    }
  }
</style>