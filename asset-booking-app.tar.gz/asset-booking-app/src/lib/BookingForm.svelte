<script lang="ts">
  import { createEventDispatcher, onMount } from 'svelte';
  import { format } from 'date-fns';
  import { z } from 'zod';
  import Calendar from './Calendar.svelte';
  import { generateAvailabilityCalendar, getAIRecommendations } from './data';
  import type { Asset, Booking } from './types';
  
  export let asset: Asset;
  
  const dispatch = createEventDispatcher<{ 
    bookingSubmit: Booking 
  }>();
  
  // Form state
  let date: string = format(new Date(), 'yyyy-MM-dd');
  let startTime: string = '09:00';
  let endTime: string = '10:00';
  let purpose: string = '';
  let errors: Record<string, string> = {};
  let availabilityCalendar: any[] = [];
  let showCalendar = false;
  let recommendations: any[] = [];
  
  // Zod schema for form validation
  const BookingSchema = z.object({
    date: z.string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, { message: "Invalid date format" }),
    startTime: z.string()
      .regex(/^([01]\d|2[0-3]):([0-5]\d)$/, { message: "Invalid start time format" }),
    endTime: z.string()
      .regex(/^([01]\d|2[0-3]):([0-5]\d)$/, { message: "Invalid end time format" })
      .refine(val => val > startTime, {
        message: "End time must be after start time"
      }),
    purpose: z.string()
      .min(5, { message: "Purpose must be at least 5 characters" })
      .max(200, { message: "Purpose cannot exceed 200 characters" })
  });
  
  // Initialize calendar data
  onMount(() => {
    const today = new Date();
    availabilityCalendar = generateAvailabilityCalendar(today, asset.id);
  });
  
  // Handle form submission
  function handleSubmit() {
    try {
      // Validate form data
      const validatedData = BookingSchema.parse({ date, startTime, endTime, purpose });
      
      // If validation passes, create booking object
      const booking: Booking = {
        assetId: asset.id,
        userId: 'current-user', // In a real app, get this from authentication
        date: new Date(date),
        startTime: validatedData.startTime,
        endTime: validatedData.endTime,
        purpose: validatedData.purpose
      };
      
      // Dispatch booking event
      dispatch('bookingSubmit', booking);
      
      // Reset form
      purpose = '';
      errors = {};
      
    } catch (err) {
      if (err instanceof z.ZodError) {
        // Convert Zod errors to a friendly format
        errors = {};
        err.errors.forEach(e => {
          errors[e.path[0]] = e.message;
        });
      }
    }
  }
  
  // Get AI recommendations when purpose changes
  $: if (purpose.length > 5) {
    recommendations = getAIRecommendations(asset.id, purpose);
  } else {
    recommendations = [];
  }
  
  function toggleCalendar() {
    showCalendar = !showCalendar;
  }
  
  function selectDate(event: CustomEvent<{ date: Date }>) {
    date = format(event.detail.date, 'yyyy-MM-dd');
    showCalendar = false;
  }
</script>

<div class="booking-form">
  <div class="asset-info">
    <h3>Selected Asset</h3>
    <p><strong>{asset.name}</strong> (ID: {asset.id})</p>
  </div>
  
  <form on:submit|preventDefault={handleSubmit}>
    <div class="form-group">
      <label for="date">Date</label>
      <div class="date-input-container">
        <input 
          type="date" 
          id="date" 
          bind:value={date} 
          min={format(new Date(), 'yyyy-MM-dd')}
          class={errors.date ? 'error' : ''}
        />
        <button 
          type="button" 
          class="calendar-button" 
          on:click={toggleCalendar}
          aria-label="Show calendar"
        >
          📅
        </button>
      </div>
      {#if errors.date}
        <p class="error-message">{errors.date}</p>
      {/if}
    </div>
    
    {#if showCalendar}
      <div class="calendar-container">
        <Calendar 
          calendar={availabilityCalendar} 
          on:selectDate={selectDate}
        />
      </div>
    {/if}
    
    <div class="form-row">
      <div class="form-group">
        <label for="startTime">Start Time</label>
        <input 
          type="time" 
          id="startTime" 
          bind:value={startTime}
          class={errors.startTime ? 'error' : ''}
        />
        {#if errors.startTime}
          <p class="error-message">{errors.startTime}</p>
        {/if}
      </div>
      
      <div class="form-group">
        <label for="endTime">End Time</label>
        <input 
          type="time" 
          id="endTime" 
          bind:value={endTime}
          class={errors.endTime ? 'error' : ''}
        />
        {#if errors.endTime}
          <p class="error-message">{errors.endTime}</p>
        {/if}
      </div>
    </div>
    
    <div class="form-group">
      <label for="purpose">Purpose</label>
      <textarea 
        id="purpose" 
        bind:value={purpose}
        placeholder="Describe what you'll be using this asset for..."
        rows="4"
        class={errors.purpose ? 'error' : ''}
      ></textarea>
      {#if errors.purpose}
        <p class="error-message">{errors.purpose}</p>
      {/if}
    </div>
    
    {#if recommendations.length > 0}
      <div class="ai-recommendations">
        <h4>Recommendations</h4>
        <ul>
          {#each recommendations as rec}
            <li class="recommendation {rec.type}">
              <span class="ai-icon">💡</span>
              {rec.message}
            </li>
          {/each}
        </ul>
      </div>
    {/if}
    
    <button type="submit" class="submit-btn">Book Asset</button>
  </form>
</div>

<style>
  .booking-form {
    display: flex;
    flex-direction: column;
    gap: 20px;
  }
  
  .asset-info {
    background: #f8f9fa;
    padding: 10px 15px;
    border-radius: 5px;
  }
  
  .asset-info h3 {
    margin: 0 0 5px 0;
    font-size: 1rem;
    color: #666;
  }
  
  .asset-info p {
    margin: 0;
  }
  
  form {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }
  
  .form-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
  }
  
  .form-row {
    display: flex;
    gap: 10px;
  }
  
  .form-row .form-group {
    flex: 1;
  }
  
  label {
    font-weight: bold;
    font-size: 0.9rem;
  }
  
  input, textarea {
    padding: 8px 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 0.9rem;
  }
  
  input.error, textarea.error {
    border-color: #dc3545;
    background-color: #fff8f8;
  }
  
  .error-message {
    color: #dc3545;
    font-size: 0.8rem;
    margin: 0;
  }
  
  .date-input-container {
    display: flex;
    gap: 5px;
  }
  
  .date-input-container input {
    flex: 1;
  }
  
  .calendar-button {
    background: #f8f9fa;
    border: 1px solid #ccc;
    border-radius: 4px;
    padding: 0 8px;
    cursor: pointer;
    font-size: 1rem;
  }
  
  .calendar-container {
    margin-bottom: 10px;
  }
  
  .ai-recommendations {
    background: #f0f7ff;
    border-radius: 5px;
    padding: 10px 15px;
    margin: 10px 0;
  }
  
  .ai-recommendations h4 {
    margin: 0 0 10px 0;
    font-size: 0.9rem;
    color: #0066cc;
  }
  
  .ai-recommendations ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
  }
  
  .recommendation {
    display: flex;
    align-items: flex-start;
    gap: 8px;
    margin-bottom: 8px;
    font-size: 0.9rem;
  }
  
  .ai-icon {
    font-size: 1rem;
  }
  
  .recommendation.performance {
    color: #0066cc;
  }
  
  .recommendation.availability {
    color: #6c757d;
  }
  
  .recommendation.alternative {
    color: #28a745;
  }
  
  .submit-btn {
    background: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    padding: 10px;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.2s;
    margin-top: 10px;
  }
  
  .submit-btn:hover {
    background: #0069d9;
  }
</style>